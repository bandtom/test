/*
 * msrpc-server.h
 */

#ifndef MSRPC_SERVER_H_
#define MSRPC_SERVER_H_

int runServer();

#endif /* MSRPC_SERVER_H_ */
